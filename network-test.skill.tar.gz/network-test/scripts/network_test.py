#!/usr/bin/env python3
"""
GKE Pod用ネットワーク接続性テストスクリプト
Kubernetes Pod内でnslookupとncコマンドを実行し、結果を含む画像を生成します。
"""

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import textwrap


def load_config(config_path):
    """JSONファイルから設定を読み込む"""
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def run_command_in_pod(pod_name, namespace, command):
    """Kubernetes Pod内でコマンドを実行し、出力を返す"""
    kubectl_cmd = f"kubectl exec -n {namespace} {pod_name} -- {command}"

    try:
        result = subprocess.run(
            kubectl_cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        output = result.stdout + result.stderr
        return output if output else "コマンド実行成功、出力なし"
    except subprocess.TimeoutExpired:
        return "コマンド実行タイムアウト"
    except Exception as e:
        return f"コマンド実行失敗: {str(e)}"


def create_image_from_text(text_content, output_path, width=1200):
    """テキストコンテンツから画像を生成する"""
    # 等幅フォントを使用
    try:
        font = ImageFont.truetype("/usr/share/fonts/dejavu/DejaVuSansMono.ttf", 14)
    except:
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 14)
        except:
            font = ImageFont.load_default()

    # テキストを行に分割し、長い行を折り返す
    lines = []
    for line in text_content.split('\n'):
        if line:
            wrapped = textwrap.fill(line, width=100)
            lines.extend(wrapped.split('\n'))
        else:
            lines.append('')

    # 必要な高さを計算
    line_height = 20
    padding = 20
    height = len(lines) * line_height + padding * 2

    # 実際の画像を作成
    img = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(img)

    # テキストを描画
    y = padding
    for line in lines:
        draw.text((padding, y), line, fill='black', font=font)
        y += line_height

    # 画像を保存
    img.save(output_path)
    print(f"画像保存完了: {output_path}")


def run_tests(config_path, output_dir="."):
    """設定に基づいてネットワークテストを実行する"""
    # 設定を読み込む
    config = load_config(config_path)

    # 設定を取得
    serial_number = config.get('serial_number', 'UNKNOWN')
    pod_name = config.get('pod_name', '')
    namespace = config.get('namespace', '')
    domain = config.get('domain', '')
    port = config.get('port', '')

    # 必須フィールドを検証
    if not pod_name:
        print("エラー: 設定ファイルにpod_nameフィールドがありません")
        sys.exit(1)
    if not namespace:
        print("エラー: 設定ファイルにnamespaceフィールドがありません")
        sys.exit(1)
    if not domain:
        print("エラー: 設定ファイルにdomainフィールドがありません")
        sys.exit(1)
    if not port:
        print("エラー: 設定ファイルにportフィールドがありません")
        sys.exit(1)

    # 出力ファイル名を生成
    date_str = datetime.now().strftime('%Y%m%d')
    output_filename = f"{serial_number}_{date_str}.png"
    output_path = Path(output_dir) / output_filename

    # テスト結果テキストを準備
    results = []
    results.append("=" * 80)
    results.append(f"ネットワーク接続性テストレポート")
    results.append(f"番号: {serial_number}")
    results.append(f"Pod: {pod_name}")
    results.append(f"Namespace: {namespace}")
    results.append(f"テスト実行時刻: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    results.append("=" * 80)
    results.append("")

    # テスト 1: nslookup
    results.append("-" * 80)
    results.append("テスト 1: DNS解決テスト")
    results.append("-" * 80)
    nslookup_cmd = f"nslookup {domain}"
    results.append(f"コマンド: kubectl exec -n {namespace} {pod_name} -- {nslookup_cmd}")
    results.append("")
    nslookup_output = run_command_in_pod(pod_name, namespace, nslookup_cmd)
    results.append(nslookup_output)
    results.append("")

    # テスト 2: nc -vz
    results.append("-" * 80)
    results.append("テスト 2: ポート接続性テスト")
    results.append("-" * 80)
    nc_cmd = f"nc -vz {domain} {port}"
    results.append(f"コマンド: kubectl exec -n {namespace} {pod_name} -- {nc_cmd}")
    results.append("")
    nc_output = run_command_in_pod(pod_name, namespace, nc_cmd)
    results.append(nc_output)
    results.append("")

    results.append("=" * 80)
    results.append("テスト完了")
    results.append("=" * 80)

    # すべての結果を結合
    full_text = "\n".join(results)

    # コンソールに出力
    print(full_text)
    print("")

    # 画像を作成
    create_image_from_text(full_text, str(output_path))

    return str(output_path)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("使い方: python3 network_test.py <config.json> [output_dir]")
        sys.exit(1)

    config_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "."

    run_tests(config_path, output_dir)
