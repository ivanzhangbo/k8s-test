---
name: network-test
description: Automated network connectivity testing tool that reads configuration (serial number, domain, port), executes nslookup and nc commands, and generates timestamped PNG reports. Use when users need to test network connectivity, verify DNS resolution and port accessibility, or when they mention network testing, connectivity checks, or saving test results as images.
---

# ネットワークテストスキル

このスキルは、JSONファイルから設定を読み込み、kubectlを介してDNSとポート接続性テストを実行し、コマンドと結果を含むPNG画像レポートを生成することで、GKE Pod のネットワーク接続性テストを自動化します。

## このスキルの機能

1. JSONファイルからテスト設定を読み込む（番号、Pod名、ネームスペース、ドメイン、ポート）
2. kubectl execを介してGKE Podに接続
3. Pod内で2つのネットワーク接続性テストを実行:
   - `nslookup <domain>` - DNS解決テスト
   - `nc -vz <domain> <port>` - ポート接続性テスト
4. コマンドと実行結果を含むPNG画像を生成
5. 出力画像を次の形式で命名: `<番号>_YYYYMMDD.png`

## 前提条件

- kubectlが設定されており、GKEクラスタに接続可能であること
- 対象Podに`nslookup`と`nc`コマンドがインストールされていること
- ローカル環境にPython 3とPillowライブラリがインストールされていること: `pip install Pillow`

## 設定ファイルの形式

以下の構造でJSON設定ファイルを作成します:

```json
{
  "serial_number": "TEST001",
  "pod_name": "test-pod-12345",
  "namespace": "default",
  "domain": "example.com",
  "port": "443"
}
```

必須フィールド:
- `serial_number`: テストの識別子（出力ファイル名に使用）
- `pod_name`: テストを実行するKubernetes Podの名前
- `namespace`: PodのKubernetesネームスペース
- `domain`: テスト対象のドメイン名またはIPアドレス
- `port`: 接続性をテストするポート番号

## 使用方法

### テストの実行

設定ファイルを指定してテストスクリプトを実行します:

```bash
python3 scripts/network_test.py <config.json> [output_directory]
```

パラメータ:
- `config.json`: JSON設定ファイルのパス（必須）
- `output_directory`: PNG画像を保存するディレクトリ（オプション、デフォルトはカレントディレクトリ）

### 実行例

```bash
# カレントディレクトリの設定ファイルでテストを実行
python3 scripts/network_test.py config.json

# テストを実行して特定のディレクトリに出力を保存
python3 scripts/network_test.py config.json ./reports

# スキルへのフルパスを使用
python3 ~/.claude/skills/network-test/scripts/network_test.py config.json
```

### 出力

スクリプトは以下を実行します:
1. kubectlを介して指定されたPodに接続
2. Pod内でnslookupとncコマンドを実行
3. テスト結果をコンソールに出力
4. `<番号>_<YYYYMMDD>.png`という名前のPNG画像ファイルを生成

出力ファイル名の例: `TEST001_20260125.png`

画像には以下が含まれます:
- 番号、Pod名、ネームスペース、タイムスタンプを含むテストレポートヘッダー
- nslookupテストの完全なkubectl execコマンドと出力
- ncポート接続性テストの完全なkubectl execコマンドと出力

## 設定例

サンプル設定ファイルについては`assets/config.json.example`を参照してください:

```json
{
  "serial_number": "TEST001",
  "pod_name": "test-pod-12345",
  "namespace": "default",
  "domain": "www.google.com",
  "port": "443"
}
```

## ワークフロー

ユーザーがネットワークテストを要求した場合:

1. **kubectlアクセスの確認**: kubectlが設定されており、対象クラスタにアクセスできることを確認
2. **Podの確認**: Podが存在し実行中であることを確認:
   ```bash
   kubectl get pod -n <namespace> <pod_name>
   ```
3. **設定ファイルの作成または更新**: すべての必須フィールドを含む有効なJSON設定ファイルが存在することを確認
4. **必要に応じてPillowをインストール**: `pip install Pillow`
5. **スクリプトの実行**: `python3 scripts/network_test.py <config.json> [output_dir]`を実行
6. **出力の確認**: PNG画像が正常に作成されたことを確認
7. **結果の確認**: 生成された画像を開いてテスト結果を確認

## トラブルシューティング

### kubectl接続の問題

kubectlがPodに接続できない場合:
```bash
# kubectlコンテキストの確認
kubectl config current-context

# 利用可能なPodのリスト表示
kubectl get pods -n <namespace>

# Podアクセスのテスト
kubectl exec -n <namespace> <pod_name> -- echo "Connection test"
```

### Pod内のコマンド不足

Podにnslookupまたはncがインストールされていない場合、出力画像に「command not found」エラーが表示されます。Pod内にインストールします:

```bash
# Alpineベースのイメージの場合
kubectl exec -n <namespace> <pod_name> -- apk add bind-tools netcat-openbsd

# Debian/Ubuntuベースのイメージの場合
kubectl exec -n <namespace> <pod_name> -- apt-get update && apt-get install -y dnsutils netcat
```

### Pillowライブラリの不足

Pillowがローカルにインストールされていない場合:
```bash
pip install Pillow
# または
pip3 install Pillow
```

### フォントの問題

スクリプトはDejaVu Sans Monoフォントの使用を試みます。見つからない場合はデフォルトフォントにフォールバックします。より良いレンダリングを確保するには、ローカルマシンにフォントをインストールします:

```bash
# Debian/Ubuntu
sudo apt-get install fonts-dejavu

# RedHat/CentOS
sudo yum install dejavu-sans-mono-fonts

# macOS
brew install --cask font-dejavu
```

## 技術的な注意事項

- スクリプトは`kubectl exec -n <namespace> <pod_name> -- <command>`を介してコマンドを実行します
- 各コマンドにはハングを防ぐために30秒のタイムアウトがあります
- stdoutとstderrの両方が出力にキャプチャされます
- 画像はコンテンツに合わせてサイズ調整されます（デフォルト幅: 1200px）
- テキストは読みやすさのために1行100文字で折り返されます
- すべてのタイムスタンプはファイル名にYYYYMMDD形式、表示にYYYY-MM-DD HH:MM:SS形式を使用します
- スクリプトはローカルで実行されますが、テストはPod内でリモート実行されます
