variable "project_id" {
  description = "GCP プロジェクト ID（サービスプロジェクト）"
  type        = string
}

variable "location" {
  description = "リージョン (例: asia-northeast1)"
  type        = string
}

variable "instance_id" {
  description = "Valkey インスタンス ID（projects/.../instances/{instance} の {instance} 部分）"
  type        = string
}

variable "host_project_id" {
  description = "共有 VPC を持っているホストプロジェクト ID "
  type        = string
}

variable "network_name" {
  description = "共有 VPC のネットワーク名"
  type        = string
}

variable "shard_count" {
  description = "シャード数"
  type        = number
  default     = 1
}

variable "replica_count" {
  description = "1 シャードあたりのレプリカ数（0 の場合はレプリカなし）"
  type        = number
  default     = 0
}

variable "node_type" {
  description = "ノードタイプ"
  type        = string
  default     = "SHARED_CORE_NANO"
}

variable "engine_version" {
  description = "Valkey バージョン"
  type        = string
  default     = "VALKEY_8_0"
}

variable "authorization_mode" {
  description = "認証モード (AUTH_DISABLED or IAM_AUTH)"
  type        = string
  default     = "IAM_AUTH"
}

variable "transit_encryption_mode" {
  description = "転送時暗号化モード (TRANSIT_ENCRYPTION_DISABLED or SERVER_AUTHENTICATION)"
  type        = string
  default     = "SERVER_AUTHENTICATION"
}

variable "persistence_mode" {
  description = "永続化モード (DISABLED, RDB, AOF)。Memory Snapshot は RDB。"
  type        = string
  default     = "RDB"
}

variable "labels" {
  description = "ラベル"
  type        = map(string)
  default     = {}
}
