output "name" {
  description = "完全修飾リソース名"
  value       = google_memorystore_instance.this.name
}

output "location" {
  description = "リージョン"
  value       = google_memorystore_instance.this.location
}

output "engine_version" {
  description = "実際に作成された Valkey バージョン"
  value       = google_memorystore_instance.this.engine_version
}

output "persistence_mode" {
  description = "有効な永続化モード"
  value       = google_memorystore_instance.this.persistence_config[0].mode
}
