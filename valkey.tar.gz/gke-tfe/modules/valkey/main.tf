resource "google_memorystore_instance" "this" {
  project     = var.project_id
  location    = var.location
  instance_id = var.instance_id

  # 認証・暗号化
  authorization_mode      = var.authorization_mode
  transit_encryption_mode = var.transit_encryption_mode

  # Cluster Mode 無効（単一インスタンスモード）
  mode = "CLUSTER_DISABLED"

  # キャパシティ関連
  shard_count   = var.shard_count
  replica_count = var.replica_count
  node_type     = var.node_type
  engine_version = var.engine_version

  labels = var.labels

  # Private Service Connect (サービス接続ポリシー作成済み前提)
  desired_auto_created_endpoints {
    network    = "projects/${var.host_project_id}/global/networks/${var.network_name}"
    project_id = var.project_id
  }

  # 永続化設定: デフォルト RDB (Memory Snapshot)
  persistence_config {
    mode = var.persistence_mode
  }

  # 複数ゾーン配置
  zone_distribution_config {
    mode = "MULTI_ZONE"
  }

}
