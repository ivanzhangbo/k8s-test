project_id       = "xxxx"
region           = "asia-northeast2"
env              = "dev"

host_project_id  = "host-prj"
shared_vpc_name  = "shared-vpc-main"

valkey_shard_count      = 1
valkey_replica_count    = 1
valkey_node_type        = "SHARED_CORE_NANO"
valkey_engine_version   = "VALKEY_8_0"
valkey_persistence_mode = "RDB"
