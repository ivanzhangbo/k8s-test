terraform {
  backend "gcs" {
    bucket = "ｘｘｘ"
    prefix = "memorystore_valkey"
  }
}
