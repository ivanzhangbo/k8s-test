variable "project_id" {
  description = "サービスプロジェクトID "
  type        = string
}

variable "region" {
  description = "リージョン"
  type        = string
}

variable "env" {
  description = "環境識別子"
  type        = string
}

variable "host_project_id" {
  description = "共有VPC ホストプロジェクトID"
  type        = string
}

variable "shared_vpc_name" {
  description = "共有VPCネットワーク名"
  type        = string
}

# Valkey 関連 
variable "valkey_shard_count" {
  type        = number
  default     = 1
}

variable "valkey_replica_count" {
  type        = number
  default     = 1
}

variable "valkey_node_type" {
  type        = string
  default     = "SHARED_CORE_NANO"
}

variable "valkey_engine_version" {
  type        = string
  default     = "VALKEY_8_0"
}

variable "valkey_persistence_mode" {
  type        = string
  default     = "RDB" # Memory Snapshot
}
