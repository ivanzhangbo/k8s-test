# Memorystore for Valkey モジュール
module "memorystore_valkey" {
  source = "../../modules/valkey"

  project_id       = var.project_id
  location         = var.region
  instance_id      = "valkey-${var.env}"

  host_project_id  = var.host_project_id
  network_name     = var.shared_vpc_name

  shard_count      = var.valkey_shard_count
  replica_count    = var.valkey_replica_count
  node_type        = var.valkey_node_type
  engine_version   = var.valkey_engine_version
  persistence_mode = var.valkey_persistence_mode

  labels = {
    env     = var.env
    created = "terraform"
  }
}
