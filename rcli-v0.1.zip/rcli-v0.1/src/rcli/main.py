"""CLI entrypoint."""

from __future__ import annotations

import argparse
import asyncio
import sys
import traceback
from pathlib import Path

if __package__ in {None, ""}:
    # Allow running via `python3 rcli/src/rcli/main.py`
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from rcli.config import load_app_config
from rcli.defs import load_agent
from rcli.session import chat_once, new_session

def main() -> None:
    """CLI entrypoint."""
    args = parse_args()
    if args.command != "chat":
        raise SystemExit("Only the 'chat' command is supported")

    run_chat_command(
        workspace=args.workspace,
        env_file=args.env_file,
        agent=args.agent,
    )


def parse_args() -> argparse.Namespace:
    """Parse command line arguments with stdlib only."""
    parser = argparse.ArgumentParser(prog="rcli", description="Minimal Rakuten AI CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    chat_parser = subparsers.add_parser("chat", help="Start an interactive chat session")
    chat_parser.add_argument("-w", "--workspace", default="./default_workspace", help="Workspace directory")
    chat_parser.add_argument("--env-file", default="./.env", help="Path to .env file")
    chat_parser.add_argument("-a", "--agent", default=None, help="Agent id to use")

    return parser.parse_args()


def run_chat_command(workspace: str, env_file: str, agent: str | None) -> None:
    """Start an interactive chat session."""
    workspace_path = Path(workspace).resolve()
    env_path = Path(env_file).resolve()

    try:
        workspace_config = load_app_config(workspace_path, env_path)
        agent_definition = load_agent(workspace_config, agent or workspace_config["defaultAgent"])
    except Exception as exc:
        print(f"Startup error: {exc}")
        traceback.print_exc()
        raise SystemExit(1)

    session = new_session(agent_definition, workspace_config)
    asyncio.run(run_chat_loop(session))


async def run_chat_loop(session: dict) -> None:
    """Interactive REPL."""
    agent_name = session["agent"]["id"]
    print("=" * 48)
    print(f"Welcome to rcli ({agent_name})")
    print("=" * 48)
    print("Type 'quit' or 'exit' to end the session.\n")

    round_number = 1
    while True:
        print("")
        print("=" * 72)
        print(f"Round {round_number}")
        print("=" * 72)
        try:
            user_input = await asyncio.to_thread(read_user_input)
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            return

        if user_input.lower() in {"quit", "exit", "q"}:
            print("\nGoodbye!")
            return

        if not user_input:
            continue

        try:
            answer = await chat_once(session, user_input)
        except Exception as exc:
            print(f"\nError: {exc}\n")
            traceback.print_exc()
            continue

        print("-" * 72)
        print(f"{agent_name}:")
        print(answer)
        print("-" * 72)
        round_number += 1


def read_user_input() -> str:
    """Read one user input line."""
    return input("You: ").strip()


if __name__ == "__main__":
    main()
