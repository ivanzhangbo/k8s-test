"""Session orchestration with local long-term memory.

This version intentionally removes tool-calling and keeps only:
- plain chat
- local memory persistence
- memory injection into prompt
"""

from __future__ import annotations

import json
import re
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from rcli.model import run_model_turn


def new_session(agent_definition: dict[str, Any], workspace_config: dict[str, Any]) -> dict[str, Any]:
    """Create one local chat session."""
    thread_id = workspace_config["request"]["threadId"] or str(uuid.uuid4())
    ensure_memory_dirs(workspace_config)
    return {
        "threadId": thread_id,
        "agent": agent_definition,
        "messages": [],
        "workspaceConfig": workspace_config,
    }


async def chat_once(session: dict[str, Any], user_message: str) -> str:
    """Run one chat turn with local memory support."""
    session["messages"].append({"role": "user", "content": user_message})
    save_memory_candidates(session["workspaceConfig"], user_message)
    prompt = build_prompt(session)
    model_result = await run_model_turn(
        request_config=session["workspaceConfig"]["request"],
        prompt=prompt,
        thread_id=session["threadId"],
    )
    response_text = normalize_model_text(model_result["text"])
    session["messages"].append({"role": "assistant", "content": response_text})
    save_transcript(session["workspaceConfig"], user_message, response_text)
    return response_text


def build_prompt(session: dict[str, Any]) -> str:
    """Build one plain-text prompt for the Rakuten endpoint."""
    agent = session["agent"]
    memory_block = build_memory_block(session["workspaceConfig"], session["messages"])
    history_lines = []
    for message in session["messages"]:
        if message["role"] == "user":
            history_lines.append(f'User: {message["content"]}')
            continue

        if message["role"] == "assistant":
            history_lines.append(f'Assistant: {message["content"]}')
            continue

    history_block = "\n\n".join(history_lines)

    return (
        f"# System Instructions\n{agent['prompt']}\n\n"
        f"{memory_block}\n\n"
        "# Conversation History\n"
        f"{history_block}\n\n"
        "# Response Rules\n"
        "- Answer normally in plain text.\n"
        "- Do not output JSON unless the user explicitly asks for JSON.\n"
        "- If the memory block contains relevant user facts, use them naturally.\n"
        "- If memory is missing or uncertain, say so directly."
    )


def normalize_model_text(text: str) -> str:
    """Normalize raw model text for display."""
    stripped = text.strip()
    if not stripped:
        return "(empty response)"

    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError:
        return stripped

    if isinstance(parsed, dict) and isinstance(parsed.get("content"), str):
        return parsed["content"].strip() or "(empty response)"
    return stripped


def ensure_memory_dirs(workspace_config: dict[str, Any]) -> None:
    """Create local memory directories if they do not exist."""
    memories_path = Path(workspace_config["memoriesPath"])
    (memories_path / "topics").mkdir(parents=True, exist_ok=True)
    (memories_path / "daily-notes").mkdir(parents=True, exist_ok=True)


def build_memory_block(workspace_config: dict[str, Any], messages: list[dict[str, Any]]) -> str:
    """Load related long-term memory snippets for the current turn."""
    memories = load_memory_entries(workspace_config)
    if not memories:
        return "# Long-Term Memory\nNo saved memory yet."

    recent_text = " ".join(message["content"] for message in messages[-6:] if isinstance(message.get("content"), str))
    relevant_entries = select_relevant_memories(memories, recent_text)
    if not relevant_entries:
        relevant_entries = memories[-8:]

    memory_lines = [f"- {entry['text']}" for entry in relevant_entries[:8]]
    return "# Long-Term Memory\n" + "\n".join(memory_lines)


def load_memory_entries(workspace_config: dict[str, Any]) -> list[dict[str, str]]:
    """Load memory entries from disk."""
    memory_file = Path(workspace_config["memoriesPath"]) / "topics" / "user_memory.jsonl"
    if not memory_file.exists():
        return []

    entries: list[dict[str, str]] = []
    for line in memory_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict) and isinstance(item.get("text"), str):
            entries.append({"text": item["text"], "source": str(item.get("source", ""))})
    return entries


def select_relevant_memories(memories: list[dict[str, str]], query_text: str) -> list[dict[str, str]]:
    """Select memories with simple keyword overlap.

    This intentionally uses a simple scoring rule instead of embeddings so the
    program stays dependency-light and easy to run.
    """
    query_words = tokenize_text(query_text)
    if not query_words:
        return memories[-8:]

    scored_memories: list[tuple[int, dict[str, str]]] = []
    for entry in memories:
        entry_words = tokenize_text(entry["text"])
        score = len(query_words & entry_words)
        if score > 0:
            scored_memories.append((score, entry))

    scored_memories.sort(key=lambda item: item[0], reverse=True)
    return [entry for _, entry in scored_memories]


def tokenize_text(text: str) -> set[str]:
    """Tokenize text for simple keyword overlap."""
    tokens = re.findall(r"[A-Za-z0-9_\-\u4e00-\u9fff]+", text.lower())
    return {token for token in tokens if len(token) >= 2}


def save_memory_candidates(workspace_config: dict[str, Any], user_message: str) -> None:
    """Extract a few stable user facts and save them as long-term memory."""
    candidates = extract_memory_candidates(user_message)
    if not candidates:
        return

    memory_file = Path(workspace_config["memoriesPath"]) / "topics" / "user_memory.jsonl"
    existing_entries = {entry["text"] for entry in load_memory_entries(workspace_config)}
    lines_to_append = []
    for candidate in candidates:
        if candidate in existing_entries:
            continue
        lines_to_append.append(
            json.dumps(
                {
                    "text": candidate,
                    "source": user_message,
                    "savedAt": datetime.now().isoformat(timespec="seconds"),
                },
                ensure_ascii=False,
            )
        )

    if not lines_to_append:
        return

    with memory_file.open("a", encoding="utf-8") as file:
        for line in lines_to_append:
            file.write(line + "\n")


def extract_memory_candidates(user_message: str) -> list[str]:
    """Extract stable facts from common user phrasing.

    The rule is intentionally conservative: only store likely long-term facts.
    """
    text = user_message.strip()
    lowered = text.lower()
    candidates: list[str] = []

    explicit_prefixes = [
        "remember that ",
        "remember ",
        "请记住",
        "记住",
        "记一下",
        "帮我记住",
    ]
    for prefix in explicit_prefixes:
        if lowered.startswith(prefix) or text.startswith(prefix):
            fact = text[len(prefix):].strip(" ：:,.。")
            if fact:
                candidates.append(fact)
            return deduplicate_texts(candidates)

    patterns = [
        r"(?i)\bmy name is\s+(.+)$",
        r"(?i)\bi am\s+(.+)$",
        r"(?i)\bi live in\s+(.+)$",
        r"(?i)\bi work at\s+(.+)$",
        r"(?i)\bi like\s+(.+)$",
        r"(?i)\bmy favorite\s+(.+)$",
        r"我叫(.+)$",
        r"我是(.+)$",
        r"我住在(.+)$",
        r"我在(.+?)工作$",
        r"我喜欢(.+)$",
        r"我常用(.+)$",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if not match:
            continue
        value = match.group(0).strip(" ：:,.。")
        if value:
            candidates.append(value)

    return deduplicate_texts(candidates)


def deduplicate_texts(items: list[str]) -> list[str]:
    """Deduplicate while keeping order."""
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        normalized = item.strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        result.append(normalized)
    return result


def save_transcript(workspace_config: dict[str, Any], user_message: str, assistant_message: str) -> None:
    """Append each conversation round into a daily note file."""
    daily_note = Path(workspace_config["memoriesPath"]) / "daily-notes" / f"{datetime.now():%Y-%m-%d}.md"
    with daily_note.open("a", encoding="utf-8") as file:
        file.write(f"## {datetime.now():%H:%M:%S}\n")
        file.write(f"User: {user_message}\n\n")
        file.write(f"Assistant: {assistant_message}\n\n")
