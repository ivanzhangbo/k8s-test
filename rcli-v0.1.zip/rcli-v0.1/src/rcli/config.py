"""Configuration loading helpers.

This file intentionally keeps config logic simple:
- workspace structure comes from yaml
- model / request settings come from .env
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def load_app_config(workspace_path: Path, env_file: Path) -> dict[str, Any]:
    """Load workspace config yaml and merge request settings from .env."""
    config_path = workspace_path / "config.user.yaml"
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    raw_config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    env_values = read_env_file(env_file)

    config = {
        "workspacePath": workspace_path.resolve(),
        "agentsPath": (workspace_path / raw_config.get("agentsPath", "agents")).resolve(),
        "skillsPath": (workspace_path / raw_config.get("skillsPath", "skills")).resolve(),
        "memoriesPath": (workspace_path / raw_config.get("memoriesPath", "memories")).resolve(),
        "defaultAgent": raw_config.get("defaultAgent", "pickle"),
        "request": load_request_config(env_values),
    }
    return config


def read_env_file(env_file: Path) -> dict[str, str]:
    """Read a simple KEY=VALUE .env file without extra dependencies."""
    if not env_file.exists():
        raise FileNotFoundError(f"Env file not found: {env_file}")

    env_values: dict[str, str] = {}
    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue

        key, value = line.split("=", 1)
        env_values[key.strip()] = strip_env_quotes(value.strip())

    return env_values


def strip_env_quotes(value: str) -> str:
    """Remove matching single or double quotes."""
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def load_request_config(env_values: dict[str, str]) -> dict[str, Any]:
    """Read model / API related settings from .env only."""
    required_keys = [
        "RAI_API_URL",
        "RAI_API_TOKEN",
        "RAI_ASSISTANT_ID",
    ]
    missing_keys = [key for key in required_keys if not env_values.get(key)]
    if missing_keys:
        missing_text = ", ".join(missing_keys)
        raise ValueError(f"Missing required env settings: {missing_text}")

    return {
        "apiUrl": env_values["RAI_API_URL"],
        "apiToken": env_values["RAI_API_TOKEN"],
        "assistantId": env_values["RAI_ASSISTANT_ID"],
        "threadId": env_values.get("RAI_THREAD_ID", "").strip(),
        "origin": env_values.get("RAI_ORIGIN", "https://r-ai.tsd.public.rakuten-it.com"),
        "webSearchEnabled": parse_bool(env_values.get("RAI_WEB_SEARCH_ENABLED"), default=True),
        "piimasking": parse_bool(env_values.get("RAI_PIIMASKING"), default=False),
        "timeoutSeconds": parse_int(env_values.get("RAI_TIMEOUT_SECONDS"), default=120),
        "verifySsl": parse_bool(env_values.get("RAI_VERIFY_SSL"), default=True),
    }


def parse_bool(value: str | None, default: bool) -> bool:
    """Parse a bool-like string safely."""
    if value is None or value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def parse_int(value: str | None, default: int) -> int:
    """Parse an integer safely."""
    if value is None or value == "":
        return default
    return int(value)
