---
name: skill-creator
description: Explain how to structure a reusable SKILL.md package with optional scripts and references
---

# Skill Creator

Use this skill when the user wants to create or revise a skill package.

Checklist:
- Clarify the skill's purpose.
- Keep the folder name lowercase and hyphenated.
- Put metadata in yaml frontmatter.
- Keep SKILL.md focused on workflow, not general documentation.
- Add `scripts/` only when deterministic execution is useful.
