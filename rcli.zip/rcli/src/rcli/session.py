"""Session orchestration.

This file mirrors build-your-own-openclaw 00/01/02, but keeps the flow function-based:
- build prompt from agent + history + tool protocol
- ask model
- parse final answer or tool call
- execute tools
- loop until final answer
"""

from __future__ import annotations

import json
import uuid
from typing import Any

from rcli.model import run_model_turn
from rcli.tools import execute_tool, get_tool_schemas


def new_session(agent_definition: dict[str, Any], workspace_config: dict[str, Any]) -> dict[str, Any]:
    """Create one local chat session."""
    thread_id = workspace_config["request"]["threadId"] or str(uuid.uuid4())
    return {
        "threadId": thread_id,
        "agent": agent_definition,
        "messages": [],
        "workspaceConfig": workspace_config,
    }


async def chat_once(session: dict[str, Any], user_message: str, tool_registry: dict[str, dict[str, Any]]) -> str:
    """Run one full user turn, including any tool-call loop."""
    session["messages"].append({"role": "user", "content": user_message})
    tool_schemas = get_tool_schemas(tool_registry)
    max_rounds = 8

    for _ in range(max_rounds):
        prompt = build_prompt(session, tool_schemas)
        model_result = await run_model_turn(
            request_config=session["workspaceConfig"]["request"],
            prompt=prompt,
            thread_id=session["threadId"],
        )
        response_text = model_result["text"]
        parsed_response = parse_model_response(response_text)

        if parsed_response["type"] == "final":
            final_text = parsed_response["content"]
            session["messages"].append({"role": "assistant", "content": final_text})
            return final_text

        session["messages"].append(
            {
                "role": "assistant",
                "content": response_text,
                "toolCalls": parsed_response["calls"],
            }
        )

        for call in parsed_response["calls"]:
            tool_result = await execute_tool(
                tool_registry=tool_registry,
                tool_name=call["name"],
                arguments=call.get("arguments", {}),
                workspace_config=session["workspaceConfig"],
            )
            session["messages"].append(
                {
                    "role": "tool",
                    "toolName": call["name"],
                    "toolCallId": call["id"],
                    "content": tool_result,
                }
            )

    raise RuntimeError("Tool loop exceeded the safety limit (8 rounds)")


def build_prompt(session: dict[str, Any], tool_schemas: list[dict[str, Any]]) -> str:
    """Build one plain-text prompt for the Rakuten endpoint.

    Because the endpoint shape provided by the user accepts a single text input,
    we flatten system prompt, tool instructions, and chat history into one string.
    """
    agent = session["agent"]
    history_lines = []
    for message in session["messages"]:
        if message["role"] == "user":
            history_lines.append(f'User: {message["content"]}')
            continue

        if message["role"] == "assistant":
            history_lines.append(f'Assistant: {message["content"]}')
            continue

        if message["role"] == "tool":
            history_lines.append(
                "ToolResult:"
                f' name={message["toolName"]}'
                f' id={message["toolCallId"]}'
                f'\n{message["content"]}'
            )

    # Tool protocol is explicit so the model has a deterministic target format.
    tool_protocol = build_tool_protocol(tool_schemas)
    history_block = "\n\n".join(history_lines)

    return (
        f"# System Instructions\n{agent['prompt']}\n\n"
        f"{tool_protocol}\n\n"
        "# Conversation History\n"
        f"{history_block}\n\n"
        "# Output Rule\n"
        "Return either:\n"
        '1. {"type":"final","content":"your answer"}\n'
        '2. {"type":"tool_call","calls":[{"id":"call-1","name":"read","arguments":{"path":"README.md"}}]}\n'
        "Return JSON only. Do not wrap JSON in markdown fences."
    )


def build_tool_protocol(tool_schemas: list[dict[str, Any]]) -> str:
    """Render available tools as readable JSON for the model."""
    schema_json = json.dumps(tool_schemas, ensure_ascii=False, indent=2)
    return (
        "# Available Tools\n"
        "You may call tools when needed.\n"
        "Use exact tool names and argument keys.\n"
        f"{schema_json}"
    )


def parse_model_response(response_text: str) -> dict[str, Any]:
    """Parse model output.

    Fallback rule:
    - if JSON parsing fails, treat the raw text as final answer
    """
    stripped = response_text.strip()
    if not stripped:
        return {"type": "final", "content": ""}

    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError:
        json_block = extract_json_block(stripped)
        if json_block is None:
            return {"type": "final", "content": stripped}
        try:
            parsed = json.loads(json_block)
        except json.JSONDecodeError:
            return {"type": "final", "content": stripped}

    if parsed.get("type") == "tool_call" and isinstance(parsed.get("calls"), list):
        calls = []
        for index, call in enumerate(parsed["calls"], start=1):
            if not isinstance(call, dict):
                continue
            calls.append(
                {
                    "id": str(call.get("id") or f"call-{index}"),
                    "name": str(call.get("name", "")),
                    "arguments": call.get("arguments", {}) if isinstance(call.get("arguments"), dict) else {},
                }
            )
        if calls:
            return {"type": "tool_call", "calls": calls}

    content = parsed.get("content")
    if isinstance(content, str):
        return {"type": "final", "content": content}

    return {"type": "final", "content": stripped}


def extract_json_block(text: str) -> str | None:
    """Extract a fenced or inline JSON object if the model adds extra text."""
    if "```json" in text:
        start = text.find("```json")
        end = text.find("```", start + 7)
        if end != -1:
            return text[start + 7 : end].strip()

    first_brace = text.find("{")
    last_brace = text.rfind("}")
    if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
        return text[first_brace : last_brace + 1]
    return None
