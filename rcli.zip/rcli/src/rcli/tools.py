"""Builtin tools and registry helpers.

To keep readability high, tools are plain async functions with lightweight metadata.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Awaitable, Callable

ToolFunc = Callable[..., Awaitable[str]]


def build_tool_registry(workspace_config: dict[str, Any], agent_definition: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Build builtin tools only.

    Skill support is intentionally disabled for now to reduce moving parts
    in restricted runtime environments.
    """
    registry = {
        "read": {
            "description": "Read a UTF-8 text file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path to read"},
                },
                "required": ["path"],
            },
            "handler": tool_read,
        },
        "write": {
            "description": "Write a UTF-8 text file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path to write"},
                    "content": {"type": "string", "description": "File content"},
                },
                "required": ["path", "content"],
            },
            "handler": tool_write,
        },
        "edit": {
            "description": "Replace text in a UTF-8 file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path to edit"},
                    "oldText": {"type": "string", "description": "Text to replace"},
                    "newText": {"type": "string", "description": "Replacement text"},
                },
                "required": ["path", "oldText", "newText"],
            },
            "handler": tool_edit,
        },
        "bash": {
            "description": "Execute a bash command inside the workspace",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Command to execute"},
                },
                "required": ["command"],
            },
            "handler": tool_bash,
        },
    }

    return registry


def get_tool_schemas(tool_registry: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Return tool schemas in a model-friendly shape."""
    schemas: list[dict[str, Any]] = []
    for tool_name, tool_info in tool_registry.items():
        schemas.append(
            {
                "name": tool_name,
                "description": tool_info["description"],
                "parameters": dict(tool_info["parameters"]),
            }
        )
    return schemas


async def execute_tool(
    tool_registry: dict[str, dict[str, Any]],
    tool_name: str,
    arguments: dict[str, Any],
    workspace_config: dict[str, Any],
) -> str:
    """Execute one tool call safely."""
    tool_info = tool_registry.get(tool_name)
    if tool_info is None:
        return f"Error: unknown tool '{tool_name}'"

    handler: ToolFunc = tool_info["handler"]
    try:
        return await handler(workspace_config=workspace_config, **arguments)
    except Exception as exc:
        return f"Error executing tool '{tool_name}': {exc}"


def resolve_workspace_path(workspace_config: dict[str, Any], raw_path: str) -> Path:
    """Resolve relative paths inside the active workspace."""
    path = Path(raw_path)
    if path.is_absolute():
        return path
    return Path(workspace_config["workspacePath"]) / path


async def tool_read(path: str, workspace_config: dict[str, Any], **_: Any) -> str:
    """Read a text file."""
    file_path = resolve_workspace_path(workspace_config, path)
    return file_path.read_text(encoding="utf-8")


async def tool_write(path: str, content: str, workspace_config: dict[str, Any], **_: Any) -> str:
    """Write a text file."""
    file_path = resolve_workspace_path(workspace_config, path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content, encoding="utf-8")
    return f"Successfully wrote {file_path}"


async def tool_edit(
    path: str,
    oldText: str,
    newText: str,
    workspace_config: dict[str, Any],
    **_: Any,
) -> str:
    """Replace a string in a text file."""
    file_path = resolve_workspace_path(workspace_config, path)
    content = file_path.read_text(encoding="utf-8")
    if oldText not in content:
        return f"Error: target text not found in {file_path}"

    file_path.write_text(content.replace(oldText, newText), encoding="utf-8")
    return f"Successfully edited {file_path}"


async def tool_bash(command: str, workspace_config: dict[str, Any], **_: Any) -> str:
    """Run a bash command inside workspace and return stdout/stderr."""
    process = await asyncio.create_subprocess_shell(
        command,
        cwd=str(workspace_config["workspacePath"]),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    output = (stdout or b"").decode("utf-8", errors="replace")
    error = (stderr or b"").decode("utf-8", errors="replace")
    if output and error:
        return f"{output}\n{error}"
    return output or error or "Command completed with no output"
