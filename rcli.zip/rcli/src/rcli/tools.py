"""Builtin tools and registry helpers.

To keep readability high, tools are plain async functions with lightweight metadata.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Awaitable, Callable

from rcli.defs import discover_skills, load_skill

ToolFunc = Callable[..., Awaitable[str]]


def build_tool_registry(workspace_config: dict[str, Any], agent_definition: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Build builtin tools and optionally the dynamic skill tool."""
    registry = {
        "read": {
            "description": "Read a UTF-8 text file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path to read"},
                },
                "required": ["path"],
            },
            "handler": tool_read,
        },
        "write": {
            "description": "Write a UTF-8 text file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path to write"},
                    "content": {"type": "string", "description": "File content"},
                },
                "required": ["path", "content"],
            },
            "handler": tool_write,
        },
        "edit": {
            "description": "Replace text in a UTF-8 file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path to edit"},
                    "oldText": {"type": "string", "description": "Text to replace"},
                    "newText": {"type": "string", "description": "Replacement text"},
                },
                "required": ["path", "oldText", "newText"],
            },
            "handler": tool_edit,
        },
        "bash": {
            "description": "Execute a bash command inside the workspace",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Command to execute"},
                },
                "required": ["command"],
            },
            "handler": tool_bash,
        },
    }

    if agent_definition.get("allowSkills"):
        registry["skill"] = build_skill_tool(workspace_config)

    return registry


def build_skill_tool(workspace_config: dict[str, Any]) -> dict[str, Any]:
    """Build the dynamic skill tool from the current skills directory."""
    skills = discover_skills(workspace_config)
    skill_ids = [skill["id"] for skill in skills]

    # We keep the description verbose on purpose so the model can see what exists
    # without loading every SKILL.md upfront.
    skill_lines = [
        f'- {skill["id"]}: {skill["description"]}'
        for skill in skills
    ]
    description = "Load one skill by id.\nAvailable skills:\n" + ("\n".join(skill_lines) if skill_lines else "- none")

    async def skill_handler(skillName: str = "", **_: Any) -> str:
        if not skillName:
            return "Error: missing required argument 'skillName'"
        skill_definition = load_skill(workspace_config, skillName)
        return skill_definition["content"]

    return {
        "description": description,
        "parameters": {
            "type": "object",
            "properties": {
                "skillName": {
                    "type": "string",
                    "description": "Skill id to load",
                    "enum": skill_ids or None,
                }
            },
            "required": ["skillName"],
        },
        "handler": skill_handler,
    }


def get_tool_schemas(tool_registry: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Return tool schemas in a model-friendly shape."""
    schemas: list[dict[str, Any]] = []
    for tool_name, tool_info in tool_registry.items():
        properties = dict(tool_info["parameters"])
        if properties.get("properties") and properties["properties"].get("skillName", {}).get("enum") is None:
            properties["properties"]["skillName"].pop("enum", None)

        schemas.append(
            {
                "name": tool_name,
                "description": tool_info["description"],
                "parameters": properties,
            }
        )
    return schemas


async def execute_tool(
    tool_registry: dict[str, dict[str, Any]],
    tool_name: str,
    arguments: dict[str, Any],
    workspace_config: dict[str, Any],
) -> str:
    """Execute one tool call safely."""
    tool_info = tool_registry.get(tool_name)
    if tool_info is None:
        return f"Error: unknown tool '{tool_name}'"

    handler: ToolFunc = tool_info["handler"]
    try:
        return await handler(workspace_config=workspace_config, **arguments)
    except Exception as exc:
        return f"Error executing tool '{tool_name}': {exc}"


def resolve_workspace_path(workspace_config: dict[str, Any], raw_path: str) -> Path:
    """Resolve relative paths inside the active workspace."""
    path = Path(raw_path)
    if path.is_absolute():
        return path
    return Path(workspace_config["workspacePath"]) / path


async def tool_read(path: str, workspace_config: dict[str, Any], **_: Any) -> str:
    """Read a text file."""
    file_path = resolve_workspace_path(workspace_config, path)
    return file_path.read_text(encoding="utf-8")


async def tool_write(path: str, content: str, workspace_config: dict[str, Any], **_: Any) -> str:
    """Write a text file."""
    file_path = resolve_workspace_path(workspace_config, path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content, encoding="utf-8")
    return f"Successfully wrote {file_path}"


async def tool_edit(
    path: str,
    oldText: str,
    newText: str,
    workspace_config: dict[str, Any],
    **_: Any,
) -> str:
    """Replace a string in a text file."""
    file_path = resolve_workspace_path(workspace_config, path)
    content = file_path.read_text(encoding="utf-8")
    if oldText not in content:
        return f"Error: target text not found in {file_path}"

    file_path.write_text(content.replace(oldText, newText), encoding="utf-8")
    return f"Successfully edited {file_path}"


async def tool_bash(command: str, workspace_config: dict[str, Any], **_: Any) -> str:
    """Run a bash command inside workspace and return stdout/stderr."""
    process = await asyncio.create_subprocess_shell(
        command,
        cwd=str(workspace_config["workspacePath"]),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    output = (stdout or b"").decode("utf-8", errors="replace")
    error = (stderr or b"").decode("utf-8", errors="replace")
    if output and error:
        return f"{output}\n{error}"
    return output or error or "Command completed with no output"
