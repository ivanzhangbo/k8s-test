"""Rakuten AI stream request wrapper.

The user-provided API is not OpenAI-compatible function calling, so we use a small
JSON text protocol on top of the plain streamed text response.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

import requests


async def run_model_turn(
    request_config: dict[str, Any],
    prompt: str,
    thread_id: str,
) -> dict[str, Any]:
    """Send one streamed request and return both text and raw events."""
    return await run_model_turn_in_thread(request_config, prompt, thread_id)


async def run_model_turn_in_thread(
    request_config: dict[str, Any],
    prompt: str,
    thread_id: str,
) -> dict[str, Any]:
    """Run the blocking HTTP request in a worker thread."""
    return await asyncio.to_thread(run_model_turn_sync, request_config, prompt, thread_id)


def run_model_turn_sync(
    request_config: dict[str, Any],
    prompt: str,
    thread_id: str,
) -> dict[str, Any]:
    """Blocking implementation using requests for broad compatibility."""
    headers = {
        "Accept": "application/json, text/event-stream",
        "Content-Type": "application/json",
        "Authorization": f'Bearer {request_config["apiToken"]}',
        "Origin": request_config["origin"],
    }
    payload = {
        "input": [
            {
                "content": prompt,
                "type": "human",
                "web_search_enabled": request_config["webSearchEnabled"],
                "piimasking": request_config["piimasking"],
            }
        ],
        "assistant_id": request_config["assistantId"],
        "thread_id": thread_id,
    }

    raw_events: list[str] = []
    text_fragments: list[str] = []
    response = requests.post(
        request_config["apiUrl"],
        headers=headers,
        json=payload,
        stream=True,
        timeout=request_config["timeoutSeconds"],
        verify=request_config["verifySsl"],
    )
    response.raise_for_status()

    for raw_line in response.iter_lines(decode_unicode=True):
        line = raw_line or ""
        if not line:
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            raw_events.append(line)
            continue
        if not line.startswith("data:"):
            raw_events.append(line)
            continue

        event_data = line[5:].strip()
        raw_events.append(event_data)
        if event_data == "[DONE]":
            break

        append_stream_text(event_data, text_fragments)

    return {
        "text": "".join(text_fragments).strip(),
        "rawEvents": raw_events,
    }


def append_stream_text(event_data: str, text_fragments: list[str]) -> None:
    """Parse one SSE data payload and append any detected text chunk."""
    try:
        payload = json.loads(event_data)
    except json.JSONDecodeError:
        text_fragments.append(event_data)
        return

    chunk = extract_text_from_payload(payload)
    if chunk:
        text_fragments.append(chunk)


def extract_text_from_payload(payload: Any) -> str:
    """Extract text from several common stream payload shapes.

    The exact Rakuten payload shape was not provided, so this helper is intentionally
    permissive and checks several common response formats.
    """
    if isinstance(payload, str):
        return payload

    if isinstance(payload, list):
        return "".join(extract_text_from_payload(item) for item in payload)

    if not isinstance(payload, dict):
        return ""

    direct_keys = [
        "text",
        "content",
        "output_text",
        "message",
        "delta",
        "token",
        "answer",
    ]
    for key in direct_keys:
        value = payload.get(key)
        if isinstance(value, str):
            return value

    choices = payload.get("choices")
    if isinstance(choices, list) and choices:
        first_choice = choices[0]
        if isinstance(first_choice, dict):
            delta = first_choice.get("delta")
            if isinstance(delta, dict):
                content = delta.get("content")
                if isinstance(content, str):
                    return content
            message = first_choice.get("message")
            if isinstance(message, dict):
                content = message.get("content")
                if isinstance(content, str):
                    return content

    output = payload.get("output")
    if isinstance(output, list):
        return "".join(extract_text_from_payload(item) for item in output)

    return ""
