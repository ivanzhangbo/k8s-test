"""Load AGENT.md / SKILL.md definitions.

The format is copied from build-your-own-openclaw:
- optional yaml frontmatter
- markdown body
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, TypeVar

import yaml

ParsedType = TypeVar("ParsedType")


def parse_definition(
    content: str,
    definition_id: str,
    parse_func: Callable[[str, dict[str, Any], str], ParsedType],
) -> ParsedType:
    """Parse yaml frontmatter + markdown body."""
    if not content.startswith("---\n"):
        return parse_func(definition_id, {}, content)

    end_marker = content.find("\n---\n", 4)
    if end_marker == -1:
        return parse_func(definition_id, {}, content)

    frontmatter_text = content[4:end_marker]
    body = content[end_marker + 5 :]
    frontmatter = yaml.safe_load(frontmatter_text) or {}
    return parse_func(definition_id, frontmatter, body)


def load_agent(workspace_config: dict[str, Any], agent_id: str) -> dict[str, Any]:
    """Load one agent definition from AGENT.md."""
    agent_file = Path(workspace_config["agentsPath"]) / agent_id / "AGENT.md"
    if not agent_file.exists():
        raise FileNotFoundError(f"Agent not found: {agent_file}")

    content = agent_file.read_text(encoding="utf-8")
    return parse_definition(content, agent_id, parse_agent_definition)


def parse_agent_definition(
    definition_id: str,
    frontmatter: dict[str, Any],
    body: str,
) -> dict[str, Any]:
    """Convert AGENT.md into a plain dict."""
    return {
        "id": definition_id,
        "name": frontmatter.get("name", definition_id),
        "description": frontmatter.get("description", ""),
        "allowSkills": bool(frontmatter.get("allow_skills", False)),
        "prompt": body.strip(),
    }


def discover_skills(workspace_config: dict[str, Any]) -> list[dict[str, str]]:
    """Return all valid skills in skillsPath."""
    skills_path = Path(workspace_config["skillsPath"])
    if not skills_path.exists():
        return []

    skills: list[dict[str, str]] = []
    for child in sorted(skills_path.iterdir()):
        if not child.is_dir():
            continue

        skill_file = child / "SKILL.md"
        if not skill_file.exists():
            continue

        content = skill_file.read_text(encoding="utf-8")
        skill_definition = parse_definition(content, child.name, parse_skill_definition)
        skills.append(skill_definition)

    return skills


def parse_skill_definition(
    definition_id: str,
    frontmatter: dict[str, Any],
    body: str,
) -> dict[str, str]:
    """Convert SKILL.md into a plain dict."""
    return {
        "id": definition_id,
        "name": str(frontmatter.get("name", definition_id)),
        "description": str(frontmatter.get("description", "")),
        "content": body.strip(),
    }


def load_skill(workspace_config: dict[str, Any], skill_id: str) -> dict[str, str]:
    """Load one skill from disk."""
    skill_file = Path(workspace_config["skillsPath"]) / skill_id / "SKILL.md"
    if not skill_file.exists():
        raise FileNotFoundError(f"Skill not found: {skill_file}")

    content = skill_file.read_text(encoding="utf-8")
    return parse_definition(content, skill_id, parse_skill_definition)
