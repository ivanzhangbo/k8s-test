output "ssl_policy" {
  description = "The SSL policy created"
  value = {
    name      = google_compute_ssl_policy.custom_policy.name
    self_link = google_compute_ssl_policy.custom_policy.self_link
  }
}