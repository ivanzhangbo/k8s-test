# 既存の外向け IP (Global external ALB 用) を参照
data "google_compute_global_address" "lb_ip" {
  project = var.project_id
  name    = "eip-cardapply-global-stg-001" # 既存のIPアドレス名
}

locals {
  # Flatten listener configuration and zones to list individual NEGs
  neg_list = flatten([
    for l_key, l_val in var.listeners : [
      for i, z in var.zones : {
        key      = "${l_key}-${z}"
        listener = l_key
        zone     = z
        neg_name = l_val.neg_names[i]
      }
    ]
  ])
}

# 既存 Zonal NEG を参照
# Flattened map for lookup
data "google_compute_network_endpoint_group" "backend_negs" {
  for_each = { for item in local.neg_list : item.key => item }

  project = var.project_id
  name    = each.value.neg_name
  zone    = each.value.zone
}

data "google_certificate_manager_certificate_map" "existing_map" {
  name    = "ert-map-cardapply-stg"
  project = "rcard-customer-stg-478910"
}


# HTTP Health Check (Per Listener)
resource "google_compute_health_check" "http" {
  for_each = var.listeners

  project = var.project_id
  name    = "${var.lb_name}-hc-${each.value.port}"

  http_health_check {
    port         = each.value.health_check_port
    request_path = "/"
  }

  check_interval_sec  = 10
  timeout_sec         = 5
  healthy_threshold   = 2
  unhealthy_threshold = 2
}

# Backend Service (NEG backend, EXTERNAL) (Per Listener)
resource "google_compute_backend_service" "https" {
  for_each = var.listeners

  project               = var.project_id
  name                  = "${var.lb_name}-backend-${each.value.port}"
  protocol              = "HTTPS"
  load_balancing_scheme = "EXTERNAL_MANAGED"
  timeout_sec           = 10

  health_checks = [google_compute_health_check.http[each.key].id]

  session_affinity        = "GENERATED_COOKIE"
  affinity_cookie_ttl_sec = 300

  dynamic "backend" {
    for_each = var.zones
    content {
      # Construct the key used in data source
      group                 = data.google_compute_network_endpoint_group.backend_negs["${each.key}-${backend.value}"].id
      balancing_mode        = "RATE"
      max_rate_per_endpoint = 100
      capacity_scaler       = 1.0
    }
  }
}

# URL Map (全パス同じ backend) (Per Listener)
resource "google_compute_url_map" "https" {
  for_each = var.listeners

  project         = var.project_id
  name            = "${var.lb_name}-urlmap-${each.value.port}"
  default_service = google_compute_backend_service.https[each.key].id
}

resource "google_compute_ssl_policy" "custom_policy" {
  project         = var.project_id
  name            = var.ssl_policy_name
  profile         = var.ssl_policy_profile
  min_tls_version = var.ssl_policy_min_tls_version
}

# HTTPS Target Proxy (Certificate Manager 証明書使用) (Per Listener)
resource "google_compute_target_https_proxy" "https" {
  for_each = var.listeners

  project = var.project_id
  name    = "${var.lb_name}-https-proxy-${each.value.port}"
  url_map = google_compute_url_map.https[each.key].id

  # Certificate Manager の certificate を直接指定
  certificate_map = "//certificatemanager.googleapis.com/projects/${data.google_certificate_manager_certificate_map.existing_map.project}/locations/global/certificateMaps/${data.google_certificate_manager_certificate_map.existing_map.name}"

  # 必要なら SSL ポリシー
  ssl_policy = google_compute_ssl_policy.custom_policy.self_link
}

# Forwarding Rule (外部 ALB フロントエンド) (Per Listener)
resource "google_compute_global_forwarding_rule" "https" {
  for_each = var.listeners

  project               = var.project_id
  name                  = "${var.lb_name}-fr-${each.value.port}"
  ip_protocol           = "TCP"
  load_balancing_scheme = "EXTERNAL_MANAGED"
  port_range            = each.value.port

  target     = google_compute_target_https_proxy.https[each.key].id
  ip_address = data.google_compute_global_address.lb_ip.address
  labels     = var.labels
}
