variable "project_id" {
  description = "ALB を作成するプロジェクト ID"
  type        = string
}

variable "host_project_id" {
  description = "共有 VPC ホストプロジェクト ID"
  type        = string
  default     = null
}

variable "shared_vpc_name" {
  description = "共有 VPC 名"
  type        = string
  default     = null
}

variable "subnetwork_name" {
  description = "サブネット名"
  type        = string
  default     = null
}

variable "zones" {
  description = "ゾーン (例: asia-northeast1-a)"
  type        = list(string)
  default     = null
}

variable "lb_name" {
  description = "ロードバランサ関連リソースのベース名"
  type        = string
}

variable "labels" {
  description = "共通で付与するラベル"
  type = map(string)
  default = {}
}

variable "ssl_policy_name" {
  description = "SSL Policy名"
  type = string
  default = null
}

variable "ssl_policy_profile" {
  description = "SSL PolicyのProfile"
  type = string
  default = "MODERN"
}

variable "ssl_policy_min_tls_version" {
  description = "SSL PolicyのMin Tls Version"
  type = string
  default = "TLS_1_2"
}

variable "listeners" {
  description = "Map of listener configurations. Key is a unique identifier (e.g., 'port-8086')."
  type = map(object({
    port              = number
    neg_names         = list(string)
    health_check_port = number
  }))
}


