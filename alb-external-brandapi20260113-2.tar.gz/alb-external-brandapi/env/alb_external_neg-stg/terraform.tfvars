project_id           = "rcard-customer-stg-478910"
host_project_id      = "rcard-common-sharedvpc-478910"
shared_vpc_name      = "rcard-shared-vpc"
zones                = ["asia-northeast2-a", "asia-northeast2-b", "asia-northeast2-c"]
lb_name              = "app-global-external-alb-stg"

labels = {
  env    = "stg"
  system = "cardapply"
}

ssl_policy_name            = "rcard-apply-ssl-policy"
ssl_policy_profile         = "COMPATIBLE"
ssl_policy_min_tls_version = "TLS_1_2"

listeners = {
  "port-8086" = {
    port              = 8086
    neg_names         = ["gke-test-neg01", "gke-test-neg01", "gke-test-neg01"]
    health_check_port = 8086
  }
  "port-8083" = {
    port              = 8083
    neg_names         = ["gke-test-neg02", "gke-test-neg02", "gke-test-neg02"]
    health_check_port = 8083
  }
  "port-8082" = {
    port              = 8082
    neg_names         = ["gke-test-neg03", "gke-test-neg03", "gke-test-neg03"]
    health_check_port = 8082
  }
}