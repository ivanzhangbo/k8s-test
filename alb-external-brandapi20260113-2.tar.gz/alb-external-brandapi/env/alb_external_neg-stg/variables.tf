variable "project_id" {
  description = "ALB を作成するサービスプロジェクト ID"
  type        = string
}

variable "zones" {
  description = "GCPゾーン"
  type        = list(string)
}

variable "host_project_id" {
  description = "共有 VPC ホストプロジェクト ID"
  type        = string
}

variable "shared_vpc_name" {
  description = "共有 VPC ネットワーク名"
  type        = string
}

variable "lb_name" {
  description = "ロードバランサ関連リソースのベース名"
  type        = string
}

variable "listeners" {
  description = "Map of listener configurations"
  type = map(object({
    port              = number
    neg_names         = list(string)
    health_check_port = number
  }))
}

variable "labels" {
  description = "リソースに付与するラベル"
  type        = map(string)
  default     = {}
}

variable "ssl_policy_name" {
  description = "SSL Policy名"
  type        = string
  default     = null
}

variable "ssl_policy_profile" {
  description = "SSL PolicyのProfile"
  type        = string
  default     = "MODERN"
}

variable "ssl_policy_min_tls_version" {
  description = "SSL PolicyのMin Tls Version"
  type        = string
  default     = "TLS_1_2"
}
