locals {
  network_uri = "projects/${var.host_project_id}/global/networks/${var.shared_vpc_name}"
}

module "alb_external_neg" {
  source = "../../modules/alb_external_neg"

  project_id                 = var.project_id
  host_project_id            = var.host_project_id
  shared_vpc_name            = var.shared_vpc_name
  zones                      = var.zones
  lb_name                    = var.lb_name
  listeners                  = var.listeners
  labels                     = var.labels
  ssl_policy_name            = var.ssl_policy_name
  ssl_policy_profile         = var.ssl_policy_profile
  ssl_policy_min_tls_version = var.ssl_policy_min_tls_version
}