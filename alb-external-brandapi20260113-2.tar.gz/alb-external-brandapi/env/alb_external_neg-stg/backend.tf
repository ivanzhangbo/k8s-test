terraform {
  backend "gcs" {
    bucket = "gcs-cardapply-osakatf001"
    prefix = "alb_external_neg-stg-brandapi"
  }
}
