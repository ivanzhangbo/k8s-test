project_id = "rcard-customer-stg-478910"
policy_name = "alb-armor-policy-stg"
rules = [
  {
    priority      = 1000
    description   = "RC が接続試験をする為"
    action        = "allow"
    src_ip_ranges = ["133.237.7.64/27", "133.237.92.64/27", "133.237.7.127/32", "133.237.92.10/32"]
  },
  {
    priority      = 1100
    description   = "Zscaler"
    action        = "allow"
    src_ip_ranges = ["167.103.40.8/32", "167.103.41.8/32"]
  },
  {
    priority      = 1501
    description   = "ninja-scan"
    action        = "allow"
    src_ip_ranges = ["64.39.96.0/20", "139.87.112.0/23"]
  },
  {
    priority      = 2000
    description   = "Akamai(SiteShield-PRD)"
    action        = "allow"
    src_ip_ranges = ["184.50.112.0/24", "104.102.24.0/24", "104.75.169.0/24", "163.139.173.128/25", "210.57.59.128/26", "210.57.59.192/27"]
  },
  {
    priority      = 2001
    description   = "Akamai(SiteShield-PRD)"
    action        = "allow"
    src_ip_ranges = ["23.200.54.0/24", "23.199.34.0/24", "23.210.215.0/24", "23.58.158.0/24"]
  },
  {
    priority      = 2002
    description   = "Akamai(SiteShield-PRD)"
    action        = "allow"
    src_ip_ranges = ["23.44.51.0/24", "23.45.50.0/24", "23.61.244.0/24", "23.61.250.0/24", "23.62.9.0/24", "61.213.168.0/24"]
  },
  {
    priority      = 2003
    description   = "Akamai(SiteShield-PRD)"
    action        = "allow"
    src_ip_ranges = ["23.67.73.0/24"]
  },
  {
    priority      = 2004
    description   = "STG check proxy テスト用の暫定設定"
    action        = "allow"
    src_ip_ranges = ["133.237.5.22/32"]
  },
  {
    priority      = 2100
    description   = "Akamai(SiteShield-STG)"
    action        = "allow"
    src_ip_ranges = ["67.220.142.19/32", "67.220.142.20/32", "67.220.142.21/32", "66.198.8.142/32", "66.198.8.144/32", "23.48.168.0/22", "23.50.48.0/20", "67.220.142.22/32", "198.8.141.0/32", "66.198.8.143/32"]
  },
  {
    priority      = 2147483647
    description   = "Default rule, higher priority overrides it"
    action        = "deny(403)"
    src_ip_ranges = ["*"]
  }
]
