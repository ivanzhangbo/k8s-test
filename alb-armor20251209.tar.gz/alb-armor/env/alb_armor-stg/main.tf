module "alb_armor" {
  source = "../../modules/alb_armor"

  project_id  = var.project_id
  policy_name = var.policy_name
  rules       = var.rules
}