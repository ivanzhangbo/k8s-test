variable "project_id" {
  description = "The ID of the project in which to create the security policy."
  type        = string
}

variable "policy_name" {
  description = "The name of the security policy."
  type        = string
}

variable "rules" {
  description = "A list of rules to apply to the security policy."
  type = list(object({
    priority      = number
    description   = string
    action        = string
    src_ip_ranges = list(string)
  }))
  default = []
}
