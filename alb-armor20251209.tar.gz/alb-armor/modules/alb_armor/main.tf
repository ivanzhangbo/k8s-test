resource "google_compute_security_policy" "default" {
  project     = var.project_id
  name        = var.policy_name
  description = "Cloud Armor security policy for ${var.policy_name}"

  dynamic "rule" {
    for_each = var.rules
    content {
      priority    = rule.value.priority
      description = rule.value.description
      action      = rule.value.action
      match {
        versioned_expr = "SRC_IPS_V1"
        config {
          src_ip_ranges = rule.value.src_ip_ranges
        }
      }
    }
  }
}
